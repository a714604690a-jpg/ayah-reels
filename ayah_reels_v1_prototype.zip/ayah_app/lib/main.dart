import 'package:flutter/material.dart';

void main() => runApp(const AyahApp());

const green = Color(0xFF0D5C4A);
const cream = Color(0xFFF8F4EA);
const gold = Color(0xFFC6A15B);

class AyahApp extends StatelessWidget {
  const AyahApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'آية',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: cream,
        colorScheme: ColorScheme.fromSeed(seedColor: green),
        fontFamily: 'Arial',
        appBarTheme: const AppBarTheme(
          backgroundColor: cream,
          foregroundColor: Colors.black87,
          centerTitle: true,
        ),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  void open(BuildContext context, Widget page) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('آية', style: TextStyle(fontWeight: FontWeight.bold)),
          actions: [
            IconButton(
              icon: const Icon(Icons.settings_outlined),
              onPressed: () => open(context, const SettingsPage()),
            )
          ],
        ),
        body: Padding(
          padding: const EdgeInsets.all(18),
          child: ListView(
            children: [
              const SizedBox(height: 8),
              const Text('مرحباً بك',
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              const Text('اصنع مقطعاً قرآنياً جميلاً في دقائق',
                  style: TextStyle(fontSize: 16, color: Colors.black54)),
              const SizedBox(height: 22),
              FilledButton.icon(
                style: FilledButton.styleFrom(
                  backgroundColor: green,
                  padding: const EdgeInsets.symmetric(vertical: 17),
                ),
                onPressed: () => open(context, const VersePage()),
                icon: const Icon(Icons.add),
                label: const Text('إنشاء ريلز جديد',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(child: _HomeCard(
                    icon: Icons.video_library_outlined,
                    title: 'مشاريعي',
                    subtitle: 'مشاهدة المشاريع السابقة',
                    onTap: () {},
                  )),
                  const SizedBox(width: 12),
                  Expanded(child: _HomeCard(
                    icon: Icons.landscape_outlined,
                    title: 'الخلفيات',
                    subtitle: 'اكتشف المزيد',
                    onTap: () => open(context, const BackgroundPage()),
                  )),
                ],
              ),
              const SizedBox(height: 26),
              const Text('أحدث المشاريع',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              Row(
                children: [
                  _ProjectCard(label: 'جبال', icon: Icons.landscape),
                  _ProjectCard(label: 'بحر', icon: Icons.water),
                  _ProjectCard(label: 'سماء', icon: Icons.cloud),
                ],
              ),
              const SizedBox(height: 30),
              const Divider(),
              const SizedBox(height: 12),
              const Center(
                child: Text('مجاني بالكامل • إعلانات بسيطة • بدون مشتريات',
                    style: TextStyle(color: Colors.black54)),
              ),
            ],
          ),
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: 0,
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.folder_outlined), label: 'مشاريعي'),
            NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'الإعدادات'),
          ],
        ),
      ),
    );
  }
}

class _HomeCard extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  final VoidCallback onTap;
  const _HomeCard({required this.icon, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) => Card(
    elevation: 0,
    child: InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Icon(icon, color: green, size: 32),
            const SizedBox(height: 8),
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 3),
            Text(subtitle, textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12, color: Colors.black54)),
          ],
        ),
      ),
    ),
  );
}

class _ProjectCard extends StatelessWidget {
  final String label;
  final IconData icon;
  const _ProjectCard({required this.label, required this.icon});

  @override
  Widget build(BuildContext context) => Expanded(
    child: Container(
      height: 110,
      margin: const EdgeInsetsDirectional.only(end: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: const LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: [Color(0xFFB8D5C7), Color(0xFFE8D7B0)],
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 34, color: green),
          const SizedBox(height: 6),
          Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
        ],
      ),
    ),
  );
}

class VersePage extends StatefulWidget {
  const VersePage({super.key});
  @override State<VersePage> createState() => _VersePageState();
}

class _VersePageState extends State<VersePage> {
  int from = 1, to = 10;
  @override
  Widget build(BuildContext context) => _Page(
    title: 'اختيار الآيات',
    child: Column(
      children: [
        const _SearchBox(hint: 'البحث عن سورة...'),
        const SizedBox(height: 14),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                const Align(
                  alignment: Alignment.centerRight,
                  child: Text('سورة البقرة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(child: _NumberBox(label: 'من آية', value: from, onChanged: (v) => setState(() => from = v))),
                    const SizedBox(width: 12),
                    Expanded(child: _NumberBox(label: 'إلى آية', value: to, onChanged: (v) => setState(() => to = v))),
                  ],
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              children: const [
                Text('بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ', textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 20, height: 1.8)),
                Divider(height: 28),
                Text('ذَٰلِكَ الْكِتَابُ لَا رَيْبَ فِيهِ ۛ هُدًى لِّلْمُتَّقِينَ',
                    textAlign: TextAlign.center, style: TextStyle(fontSize: 20, height: 1.8)),
              ],
            ),
          ),
        ),
        const Spacer(),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: green, minimumSize: const Size.fromHeight(52)),
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ReciterPage())),
          child: const Text('التالي'),
        ),
      ],
    ),
  );
}

class _SearchBox extends StatelessWidget {
  final String hint;
  const _SearchBox({required this.hint});
  @override
  Widget build(BuildContext context) => TextField(
    decoration: InputDecoration(
      hintText: hint,
      prefixIcon: const Icon(Icons.search),
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
    ),
  );
}

class _NumberBox extends StatelessWidget {
  final String label;
  final int value;
  final ValueChanged<int> onChanged;
  const _NumberBox({required this.label, required this.value, required this.onChanged});
  @override
  Widget build(BuildContext context) => DropdownButtonFormField<int>(
    value: value,
    decoration: InputDecoration(labelText: label, border: OutlineInputBorder(borderRadius: BorderRadius.circular(14))),
    items: List.generate(20, (i) => DropdownMenuItem(value: i + 1, child: Text('${i + 1}'))),
    onChanged: (v) { if (v != null) onChanged(v); },
  );
}

class ReciterPage extends StatelessWidget {
  const ReciterPage({super.key});
  @override
  Widget build(BuildContext context) => _Page(
    title: 'اختيار القارئ',
    child: Column(
      children: [
        const _SearchBox(hint: 'البحث عن قارئ...'),
        const SizedBox(height: 10),
        Expanded(
          child: ListView(
            children: [
              _Reciter(name: 'ياسر الدوسري', available: true),
              _Reciter(name: 'عبدالرحمن السديس', available: true),
              _Reciter(name: 'مشاري العفاسي', available: false),
              _Reciter(name: 'محمود الحصري', available: false),
            ],
          ),
        ),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: green, minimumSize: const Size.fromHeight(52)),
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BackgroundPage())),
          child: const Text('التالي'),
        ),
      ],
    ),
  );
}

class _Reciter extends StatelessWidget {
  final String name;
  final bool available;
  const _Reciter({required this.name, required this.available});
  @override
  Widget build(BuildContext context) => Card(
    child: ListTile(
      leading: CircleAvatar(backgroundColor: const Color(0xFFDCE9E2), child: Icon(Icons.person, color: green)),
      title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(available ? 'تلاوة متاحة بعد اعتماد الترخيص' : 'سيتم توفيرها لاحقاً'),
      trailing: IconButton(onPressed: available ? () {} : null, icon: const Icon(Icons.play_circle_outline)),
    ),
  );
}

class BackgroundPage extends StatelessWidget {
  const BackgroundPage({super.key});
  @override
  Widget build(BuildContext context) => _Page(
    title: 'اختيار الخلفية',
    child: Column(
      children: [
        const _SearchBox(hint: 'البحث عن فيديو...'),
        const SizedBox(height: 10),
        const SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(children: [
            _Chip(text: 'الكل', selected: true), _Chip(text: 'جبال'), _Chip(text: 'بحر'),
            _Chip(text: 'سماء'), _Chip(text: 'مطر'), _Chip(text: 'غابات'),
          ]),
        ),
        const SizedBox(height: 12),
        Expanded(
          child: GridView.count(
            crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10,
            children: const [
              _BackgroundTile(icon: Icons.landscape, label: 'جبال'),
              _BackgroundTile(icon: Icons.water, label: 'بحر'),
              _BackgroundTile(icon: Icons.water_drop, label: 'مطر'),
              _BackgroundTile(icon: Icons.forest, label: 'غابة'),
              _BackgroundTile(icon: Icons.wb_sunny, label: 'غروب'),
              _BackgroundTile(icon: Icons.nights_stay, label: 'سماء ليلية'),
            ],
          ),
        ),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: green, minimumSize: const Size.fromHeight(52)),
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const EditorPage())),
          child: const Text('التالي'),
        ),
      ],
    ),
  );
}

class _Chip extends StatelessWidget {
  final String text;
  final bool selected;
  const _Chip({required this.text, this.selected = false});
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsetsDirectional.only(end: 8),
    child: Chip(
      label: Text(text),
      backgroundColor: selected ? green : Colors.white,
      labelStyle: TextStyle(color: selected ? Colors.white : Colors.black87),
    ),
  );
}

class _BackgroundTile extends StatelessWidget {
  final IconData icon;
  final String label;
  const _BackgroundTile({required this.icon, required this.label});
  @override
  Widget build(BuildContext context) => Container(
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(18),
      gradient: const LinearGradient(
        begin: Alignment.topLeft, end: Alignment.bottomRight,
        colors: [Color(0xFF9EC5B5), Color(0xFFD7C08D)],
      ),
    ),
    child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 42, color: green),
      const SizedBox(height: 6),
      Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
    ])),
  );
}

class EditorPage extends StatefulWidget {
  const EditorPage({super.key});
  @override State<EditorPage> createState() => _EditorPageState();
}

class _EditorPageState extends State<EditorPage> {
  double textSize = 22;
  @override
  Widget build(BuildContext context) => _Page(
    title: 'المحرر',
    child: Column(
      children: [
        Container(
          height: 300,
          width: double.infinity,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            gradient: const LinearGradient(
              begin: Alignment.topCenter, end: Alignment.bottomCenter,
              colors: [Color(0xFF8BB5A4), Color(0xFF263F37)],
            ),
          ),
          child: Center(
            child: Text('الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white, fontSize: textSize, fontWeight: FontWeight.bold, shadows: const [Shadow(blurRadius: 8)])),
          ),
        ),
        const SizedBox(height: 10),
        SizedBox(
          height: 66,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: const [
              _Timeline(label: 'مقطع 1'),
              _Transition(),
              _Timeline(label: 'مقطع 2'),
              _Transition(),
              _Timeline(label: 'مقطع 3'),
            ],
          ),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: const [
            _Tool(icon: Icons.text_fields, label: 'النص'),
            _Tool(icon: Icons.image_outlined, label: 'الخلفية'),
            _Tool(icon: Icons.graphic_eq, label: 'الصوت'),
            _Tool(icon: Icons.auto_awesome, label: 'الانتقالات'),
          ],
        ),
        const SizedBox(height: 12),
        Row(children: [
          const Text('حجم النص'),
          Expanded(child: Slider(value: textSize, min: 14, max: 38, onChanged: (v) => setState(() => textSize = v))),
        ]),
        const Spacer(),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: green, minimumSize: const Size.fromHeight(52)),
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ExportPage())),
          child: const Text('التالي: التصدير'),
        ),
      ],
    ),
  );
}

class _Timeline extends StatelessWidget {
  final String label;
  const _Timeline({required this.label});
  @override
  Widget build(BuildContext context) => Container(
    width: 88, margin: const EdgeInsetsDirectional.only(end: 5),
    decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), color: const Color(0xFFDCE9E2)),
    child: Center(child: Text(label)),
  );
}
class _Transition extends StatelessWidget {
  const _Transition();
  @override
  Widget build(BuildContext context) => const Center(child: Padding(
    padding: EdgeInsets.symmetric(horizontal: 4),
    child: Icon(Icons.auto_awesome, size: 18, color: gold),
  ));
}
class _Tool extends StatelessWidget {
  final IconData icon; final String label;
  const _Tool({required this.icon, required this.label});
  @override
  Widget build(BuildContext context) => Column(children: [Icon(icon, color: green), const SizedBox(height: 4), Text(label, style: const TextStyle(fontSize: 12))]);
}

class ExportPage extends StatelessWidget {
  const ExportPage({super.key});
  @override
  Widget build(BuildContext context) => _Page(
    title: 'التصدير',
    child: Column(
      children: [
        Container(
          height: 350, width: double.infinity,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),
            gradient: const LinearGradient(colors: [Color(0xFF8BB5A4), Color(0xFFE0C58F)])),
          child: const Center(child: Icon(Icons.play_circle_fill, size: 64, color: Colors.white)),
        ),
        const SizedBox(height: 18),
        const Text('جودة التصدير', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        const SizedBox(height: 10),
        Row(children: const [
          Expanded(child: _Quality(text: '720p')),
          Expanded(child: _Quality(text: '1080p', selected: true)),
          Expanded(child: _Quality(text: '4K')),
        ]),
        const SizedBox(height: 12),
        const Text('نسبة العرض: 9:16', style: TextStyle(color: Colors.black54)),
        const Spacer(),
        FilledButton.icon(
          style: ButtonStyle(backgroundColor: WidgetStatePropertyAll(green), minimumSize: const WidgetStatePropertyAll(Size.fromHeight(52))),
          onPressed: () {},
          icon: const Icon(Icons.download),
          label: const Text('إنشاء الفيديو'),
        ),
      ],
    ),
  );
}

class _Quality extends StatelessWidget {
  final String text; final bool selected;
  const _Quality({required this.text, this.selected = false});
  @override
  Widget build(BuildContext context) => Card(
    color: selected ? green : Colors.white,
    child: Padding(padding: const EdgeInsets.all(12), child: Center(child: Text(text, style: TextStyle(color: selected ? Colors.white : Colors.black87)))),
  );
}

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});
  @override
  Widget build(BuildContext context) => _Page(
    title: 'الإعدادات',
    child: ListView(
      children: const [
        ListTile(leading: Icon(Icons.language), title: Text('اللغة'), trailing: Text('العربية')),
        ListTile(leading: Icon(Icons.high_quality), title: Text('جودة التصدير الافتراضية'), trailing: Text('1080p')),
        ListTile(leading: Icon(Icons.notifications_none), title: Text('الإشعارات')),
        ListTile(leading: Icon(Icons.verified_user_outlined), title: Text('المصادر والحقوق')),
        ListTile(leading: Icon(Icons.privacy_tip_outlined), title: Text('سياسة الخصوصية')),
        ListTile(leading: Icon(Icons.description_outlined), title: Text('شروط الاستخدام')),
        ListTile(leading: Icon(Icons.star_border), title: Text('تقييم التطبيق')),
        ListTile(leading: Icon(Icons.share_outlined), title: Text('مشاركة التطبيق')),
        ListTile(leading: Icon(Icons.mail_outline), title: Text('تواصل معنا')),
        ListTile(leading: Icon(Icons.info_outline), title: Text('الإصدار 1.0.0')),
      ],
    ),
  );
}

class _Page extends StatelessWidget {
  final String title;
  final Widget child;
  const _Page({required this.title, required this.child});
  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        leading: IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => Navigator.pop(context)),
      ),
      body: Padding(padding: const EdgeInsets.all(16), child: child),
    ),
  );
}
